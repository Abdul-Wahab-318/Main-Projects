
const h1=document.querySelector('#h1');

h1.addEventListener('animationend', function(){
h1.removeAttribute('data-text');
console.log('yee');
h1.innerHTML="A STUDENT...";
h1.setAttribute('data-text', 'A STUDENT...');
            
})
        
    
function showHeader()
{
    var side=document.querySelector('#sideBar'); 
    side.classList.toggle('sideBarShow');
    side.classList.toggle('sideBarRemove'); 
}


var profile=document.querySelector('#profile-img');
profile.addEventListener('click',function(){
    profile.classList.toggle('profileBounce')
})




