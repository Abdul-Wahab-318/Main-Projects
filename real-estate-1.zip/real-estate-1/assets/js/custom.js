
function displaySearch()
{
    document.getElementById('search').classList.toggle('hide');
    document.getElementById('search').classList.toggle('show');
}

function overGreen(e)
{
    e.firstElementChild.firstElementChild.style.backgroundImage="url('./assets/img/back-hover2.jpg')";
    e.firstElementChild.firstElementChild.style.backgroundSize='300px';
    e.firstElementChild.style.backgroundColor='#509407'
    e.firstElementChild.firstElementChild.nextElementSibling.style.color="white";
    e.firstElementChild.firstElementChild.nextElementSibling.nextElementSibling.style.color="#caced6";
}

function hideGreen(e)
{
    e.firstElementChild.firstElementChild.style.backgroundImage="";
    e.firstElementChild.style.backgroundColor='white'
    e.firstElementChild.firstElementChild.nextElementSibling.style.color="#07153a";
    e.firstElementChild.firstElementChild.nextElementSibling.nextElementSibling.style.color="#637cad";
}

function showVideo()
{
    console.log('function triggered');
    document.querySelector('#video').classList.toggle('hide');
    document.querySelector('#video').classList.toggle('show');
    document.querySelector('#black').classList.toggle('hide');
}

function stopVideo()
{
    document.querySelector('#player').src='';
    document.querySelector('#player').src="https://www.youtube.com/embed/9Y9wuCyMkFk";
}

$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    navText: [
        '<img width="45px" src="./assets/img/bracket-ro.svg">',
        '<img width="45px" src="./assets/img/bracket-lo.svg">'
    ],
    dots:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})