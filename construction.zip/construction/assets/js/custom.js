var i=false;
function showSearch()
{
    console.log('function runnning')
    var hiddenSearch= document.querySelector('#hiddenSearchForm');
    hiddenSearch.classList.toggle('show-form-animation');
   /* document.getElementById('searchField').focus();*/
    
}
function hiddenSearch()
{
    var hiddenSearch= document.querySelector('#hiddenSearchForm');  
    hiddenSearch.classList.remove('show-form-animation');
    console.log('hide search function')
}



$('.owl-carousel').owlCarousel({
    loop:false,
    rewind:true,
    lazyLoadEager:10,
    margin:10,
    nav:true,
    dots:false,
    navText:[
        '<img width="20px" src="./assets/img/icons/bracket-ro.svg">',
        '<img width="20px" src="./assets/img/icons/bracket-lo.svg">'
    ],
    responsive:{
        0:{
            items:1,
            
        },
        576:{
            items:4,
        },
        1000:{
            items:5,
        }
    }
})



$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    singleItem:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})











function showInfo(e)
{
    e.classList.toggle('active-heading')
    e.classList.toggle('active-border')
    var info = e.nextElementSibling;
    info.classList.toggle('d-block');
    info.classList.toggle('info-animation');
    var icon=e.firstElementChild.nextElementSibling;
    icon.classList.toggle('fa-plus');
    icon.classList.toggle('fa-minus');

}